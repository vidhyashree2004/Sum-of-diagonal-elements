public class Main {

  public static void main(String[] args) {
    int[][] arr = {{1, 5, 8},
		{4, 3, 1},
		{6, 5, 2}};

    System.out.println(" " + DiagonalSum(arr));
  }
private static int DiagonalSum(int[][] a) {
    int sum = 0;
    for (int i = 0; i < a.length; i++)
      for (int j = 0; j < a[0].length; j++) {
         if (i == j) {
            sum += a[i][j];
         }
         if (i + j == a.length - 1) {
            sum += a[i][j];
         }
       }
     return sum;
    }

}